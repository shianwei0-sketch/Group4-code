# 部署
## 环境准备
### nodejs
- 版本大于 > 22.22
- 设置mirror 
```bash
npm config set registry https://registry.npmmirror.com
```
### pnpm
```bash
# 安装pnpm
npm install -g pnpm
```
## 安装依赖
### contract
> 安装合约依赖
```bash
# 进入合约目录
cd contract
npm install
```
### eth-payment
> 安装前端依赖
```bash
# 进入前端目录
cd eth-payment
pnpm install
```
## 部署合约
- ### 本地模拟部署
```bash
# 进入合约目录
cd contract
# 启动本地节点
npx hardhat node
# 部署合约，要新打开一个终端，否则会报错
npx hardhat ignition deploy ignition/modules/Payment.ts --network localhost
```
- ### Sepolia部署
```bash
# 进入合约目录
cd contract
# 设置环境变量
set SEPOLIA_RPC_URL=https://sepolia.infura.io/v3/your-api-key
set SEPOLIA_PRIVATE_KEY=your-private-key
npx hardhat ignition deploy ignition/modules/Payment.ts --network sepolia
```
## 运行前端
### 修改合约地址
- 修改 **.env** 文件 VITE_PAYMENT_CONTRACT_ADDRESS=合约地址
### 所有前端
```bash
# 进入前端目录
cd eth-payment
pnpm run dev
```
### 访问前端
- 访问 http://localhost:5173
